import { CalendarPipe } from './calendar.pipe';

describe('CalendarPipe', () => {
  it('create an instance', () => {
    const pipe = new CalendarPipe();
    expect(pipe).toBeTruthy();
  });
});
