import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demography',
  templateUrl: './demography.component.html',
  styleUrls: ['./demography.component.css']
})
export class DemographyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
