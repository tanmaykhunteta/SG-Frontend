import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-continue-registration',
  templateUrl: './continue-registration.component.html',
  styleUrls: ['./continue-registration.component.css']
})
export class ContinueRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
