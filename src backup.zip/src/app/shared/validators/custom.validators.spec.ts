import { Custom.Validators } from './custom.validators';

describe('Custom.Validators', () => {
  it('should create an instance', () => {
    expect(new Custom.Validators()).toBeTruthy();
  });
});
